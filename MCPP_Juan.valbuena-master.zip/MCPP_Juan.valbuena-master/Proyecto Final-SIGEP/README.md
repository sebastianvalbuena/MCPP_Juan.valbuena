Install BuildTool https://visualstudio.microsoft.com/es/thank-you-downloading-visual-studio/?sku=BuildTools&rel=16#
    Ensure to check C++
    
To install Scrapy:
    !pip install scrapy
    !conda install -c conda-forge scrapy
    !pip install unidecode
    
Run main.py
    Entities needed can be set in resources/codes.json